

def count_min(c, amount):
    num = 0
    for cost in c[::-1]:
        num += int(amount/cost)
        amount %= cost
        if amount == 0:
            break
    return num


def main():
    n = int(input())
    c = []
    while n > 0:
        c.append(int(input()))
        n = n - 1
    m = int(input())
    v = []
    while m > 0:
        v.append(int(input()))
        m = m - 1
    num = 0
    for total in v:
        num += count_min(c, total)
    print(num)


if __name__ == '__main__':
    main()