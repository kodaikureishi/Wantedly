
class Stack:

    def __init__(self):
        self.array = []
        self.max_array = []

    def push(self,i):
        self.array.append(i)
        if len(self.max_array) == 0:
            self.max_array.append(i)
        elif self.max_array[-1] < i:
            self.max_array.append(i)
        else :
            self.max_array.append(self.max_array[-1])

    def pop(self,index = -1):
        value = self.array.pop(index)
        self.max_array.pop()
        return value

    def peek(self):
        value = self.array[-1]
        return value

    def max(self):
        value = self.max_array[-1]
        return value


def main():

    x = Stack()
    x.push(2)
    x.push(5)
    x.push(8)
    x.push(4)
    print(x.max())
    print(x.pop())
    print(x.max())
    print(x.pop())
    print(x.max())


if __name__ == '__main__':
    main()
